import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, MapPin, Briefcase, Calendar } from "lucide-react";
import { Link } from "wouter";

export default function Projects() {
  const projects = [
    {
      title: "Highway Infrastructure Development",
      location: "Southeast Asia",
      year: "2023",
      scope: "250 km modern highway construction with smart infrastructure integration",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp",
      category: "Infrastructure",
      details: "Complete design, engineering, and construction of a major highway corridor with advanced traffic management systems, environmental controls, and safety features.",
    },
    {
      title: "Large-Scale Mining Operation",
      location: "Australia",
      year: "2022",
      scope: "Complete mining facility with advanced processing equipment and 500+ employees",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/mining-operation-PCxFJ5VTe3mHChhJp9YYHH.webp",
      category: "Mining",
      details: "Design and construction of a state-of-the-art mining facility including extraction, processing, and environmental management systems.",
    },
    {
      title: "Manufactured Sand Plant",
      location: "India",
      year: "2023",
      scope: "Advanced sand washing and processing facility with 500 TPH capacity",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/manufactured-sand-plant-8gcqv9YyvXyjmfL3vTcnmo.webp",
      category: "Manufactured Sand",
      details: "Installation of cutting-edge sand washing technology with water recycling systems and dust suppression for sustainable production.",
    },
    {
      title: "Waste Recycling Facility",
      location: "Europe",
      year: "2022",
      scope: "Advanced waste processing and recycling center with 1000 TPD capacity",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/waste-recycling-facility-9LZVn5J9cD8kbUxjSZGd6a.webp",
      category: "Waste Management",
      details: "Comprehensive waste sorting, processing, and recycling facility with material recovery systems achieving 95% recycling rate.",
    },
    {
      title: "Urban Development Complex",
      location: "Middle East",
      year: "2021",
      scope: "Mixed-use urban development with residential, commercial, and infrastructure components",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp",
      category: "Urban Development",
      details: "Master planning and execution of a large-scale urban development project integrating modern infrastructure and smart city solutions.",
    },
    {
      title: "Bridge Construction Project",
      location: "South Asia",
      year: "2023",
      scope: "Multi-span bridge construction spanning 2 km with advanced engineering",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp",
      category: "Infrastructure",
      details: "Design and construction of a major bridge with advanced structural engineering, environmental considerations, and traffic management.",
    },
    {
      title: "Power Plant Construction",
      location: "Africa",
      year: "2022",
      scope: "500 MW power generation facility with modern technology",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp",
      category: "Energy",
      details: "Complete design, procurement, and construction of a modern power generation facility with environmental compliance systems.",
    },
    {
      title: "Construction Aggregates Facility",
      location: "North America",
      year: "2021",
      scope: "Integrated quarry and processing facility with 1000 TPD output",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/mining-operation-PCxFJ5VTe3mHChhJp9YYHH.webp",
      category: "Construction",
      details: "Development of an integrated quarry and processing facility for construction aggregates with advanced quality control systems.",
    },
  ];

  const categories = ["All", "Infrastructure", "Mining", "Manufactured Sand", "Waste Management", "Urban Development", "Energy", "Construction"];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 bg-gradient-to-br from-slate-900 to-blue-900 text-white px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Our Projects</h1>
          <p className="text-xl text-blue-100 max-w-2xl">
            Showcasing our expertise through successful projects delivered globally.
          </p>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, idx) => (
              <Card key={idx} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="inline-block bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {project.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{project.title}</h3>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-slate-600">
                      <MapPin className="h-4 w-4 text-blue-600 mr-2" />
                      <span>{project.location}</span>
                    </div>
                    <div className="flex items-center text-slate-600">
                      <Calendar className="h-4 w-4 text-blue-600 mr-2" />
                      <span>{project.year}</span>
                    </div>
                    <div className="flex items-center text-slate-600">
                      <Briefcase className="h-4 w-4 text-blue-600 mr-2" />
                      <span className="text-sm">{project.scope}</span>
                    </div>
                  </div>
                  <p className="text-slate-600 mb-4">{project.details}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Project Statistics */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Project Statistics</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { number: "500+", label: "Projects Completed" },
              { number: "$2B+", label: "Total Project Value" },
              { number: "95%", label: "On-Time Delivery" },
              { number: "98%", label: "Client Satisfaction" },
            ].map((stat, idx) => (
              <Card key={idx} className="p-6 text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <p className="text-slate-600 font-semibold">{stat.label}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-blue-600 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready for Your Next Project?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Let's discuss how DevinfraX can deliver excellence for your infrastructure needs.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
              Start Your Project <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
