import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Briefcase, Hammer, Zap, Users, Globe, TrendingUp } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-blue-900/70" />
        
        <div className="relative h-full flex items-center justify-center px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
              Building Tomorrow's Infrastructure
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-2xl mx-auto">
              DevinfraX delivers comprehensive infrastructure and industrial solutions with engineering excellence and innovation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/services">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                  Explore Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Company Introduction */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-6">About DevinfraX</h2>
              <p className="text-lg text-slate-600 mb-4">
                DevinfraX is a leading provider of infrastructure and industrial solutions, serving clients across construction, mining, manufacturing, and energy sectors globally.
              </p>
              <p className="text-lg text-slate-600 mb-6">
                With decades of combined expertise, we deliver engineered solutions that drive efficiency, sustainability, and growth for our partners.
              </p>
              <Link href="/about">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="relative h-80 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp"
                alt="Infrastructure Project"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Key Services Icons */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Our Core Services</h2>
          <div className="grid md:grid-cols-5 gap-6">
            {[
              { icon: Briefcase, title: "Engineering", desc: "Design & Planning" },
              { icon: Hammer, title: "Procurement", desc: "Supply Chain" },
              { icon: Zap, title: "Construction", desc: "Execution" },
              { icon: Users, title: "Project Mgmt", desc: "Oversight" },
              { icon: Globe, title: "Infrastructure", desc: "Development" },
            ].map((service, idx) => (
              <Card key={idx} className="p-6 text-center hover:shadow-lg transition-shadow">
                <service.icon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="font-bold text-lg text-slate-900 mb-2">{service.title}</h3>
                <p className="text-sm text-slate-600">{service.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-slate-900 to-blue-900 text-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Our Track Record</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { number: "500+", label: "Projects Completed" },
              { number: "25+", label: "Years Experience" },
              { number: "150+", label: "Global Clients" },
              { number: "45", label: "Countries Served" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-5xl font-bold text-blue-300 mb-2">{stat.number}</div>
                <p className="text-lg text-blue-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries We Serve */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Industries We Serve</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: "Construction", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp" },
              { title: "Mining", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/mining-operation-PCxFJ5VTe3mHChhJp9YYHH.webp" },
              { title: "Infrastructure", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp" },
              { title: "Manufactured Sand", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/manufactured-sand-plant-8gcqv9YyvXyjmfL3vTcnmo.webp" },
              { title: "Waste Management", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/waste-recycling-facility-9LZVn5J9cD8kbUxjSZGd6a.webp" },
              { title: "Energy & Power", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp" },
            ].map((industry, idx) => (
              <Link key={idx} href="/industries">
                <Card className="overflow-hidden hover:shadow-xl transition-shadow cursor-pointer group">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={industry.image}
                      alt={industry.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg text-slate-900">{industry.title}</h3>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/industries">
              <Button className="bg-blue-600 hover:bg-blue-700">
                View All Industries <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Featured Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Highway Infrastructure Development",
                location: "Southeast Asia",
                scope: "250 km highway construction with modern infrastructure",
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp",
              },
              {
                title: "Large-Scale Mining Operation",
                location: "Australia",
                scope: "Complete mining facility with advanced processing equipment",
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/mining-operation-PCxFJ5VTe3mHChhJp9YYHH.webp",
              },
              {
                title: "Manufactured Sand Plant",
                location: "India",
                scope: "State-of-the-art sand washing and processing facility",
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/manufactured-sand-plant-8gcqv9YyvXyjmfL3vTcnmo.webp",
              },
              {
                title: "Waste Recycling Facility",
                location: "Europe",
                scope: "Advanced waste processing and recycling center",
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/waste-recycling-facility-9LZVn5J9cD8kbUxjSZGd6a.webp",
              },
            ].map((project, idx) => (
              <Card key={idx} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-xl text-slate-900 mb-2">{project.title}</h3>
                  <p className="text-sm text-blue-600 font-semibold mb-2">{project.location}</p>
                  <p className="text-slate-600">{project.scope}</p>
                </div>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/projects">
              <Button className="bg-blue-600 hover:bg-blue-700">
                View All Projects <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Client Logos */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Trusted by Industry Leaders</h2>
          <div className="grid md:grid-cols-5 gap-8 items-center">
            {[1, 2, 3, 4, 5].map((idx) => (
              <div key={idx} className="flex items-center justify-center h-20 bg-slate-100 rounded-lg">
                <div className="text-slate-400 font-bold text-lg">Client {idx}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-blue-600 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Infrastructure?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Connect with our team to discuss your project requirements and discover how DevinfraX can deliver excellence.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg font-semibold">
              Contact Us <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
