import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Briefcase, Hammer, Zap, Users, Globe, Wrench } from "lucide-react";
import { Link } from "wouter";

export default function Services() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 bg-gradient-to-br from-slate-900 to-blue-900 text-white px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-blue-100 max-w-2xl">
            Comprehensive infrastructure and industrial solutions tailored to your needs.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {[
              {
                icon: Briefcase,
                title: "Engineering Services",
                desc: "Expert design and engineering solutions for complex infrastructure projects",
                details: [
                  "Feasibility studies and project planning",
                  "Detailed design and specifications",
                  "3D modeling and visualization",
                  "Environmental impact assessment",
                  "Regulatory compliance documentation",
                ]
              },
              {
                icon: Hammer,
                title: "Infrastructure Development",
                desc: "End-to-end infrastructure project execution and delivery",
                details: [
                  "Highway and road construction",
                  "Bridge and tunnel engineering",
                  "Urban development projects",
                  "Water and utility infrastructure",
                  "Smart city solutions",
                ]
              },
              {
                icon: Zap,
                title: "Mining Solutions",
                desc: "Specialized mining operations and resource extraction expertise",
                details: [
                  "Mine planning and design",
                  "Equipment procurement and installation",
                  "Processing plant optimization",
                  "Safety and compliance management",
                  "Environmental remediation",
                ]
              },
              {
                icon: Globe,
                title: "Manufactured Sand Solutions",
                desc: "Advanced sand washing and processing technology",
                details: [
                  "Sand washing plant design",
                  "Quality control systems",
                  "Dust suppression technology",
                  "Water recycling systems",
                  "Capacity optimization",
                ]
              },
              {
                icon: Wrench,
                title: "Waste Recycling Solutions",
                desc: "Sustainable waste management and recycling systems",
                details: [
                  "Waste processing facility design",
                  "Material recovery systems",
                  "Sorting and segregation technology",
                  "Environmental compliance",
                  "Zero-waste initiatives",
                ]
              },
              {
                icon: Users,
                title: "Project Management",
                desc: "Professional project management and oversight services",
                details: [
                  "Project planning and scheduling",
                  "Budget management and cost control",
                  "Quality assurance and testing",
                  "Stakeholder communication",
                  "Risk management",
                ]
              },
            ].map((service, idx) => (
              <Card key={idx} className="p-8 hover:shadow-lg transition-shadow">
                <service.icon className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold text-slate-900 mb-3">{service.title}</h3>
                <p className="text-slate-600 mb-6">{service.desc}</p>
                <ul className="space-y-2 mb-6">
                  {service.details.map((detail, i) => (
                    <li key={i} className="flex items-start">
                      <span className="text-blue-600 mr-3 font-bold">•</span>
                      <span className="text-slate-600">{detail}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Operation and Maintenance */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Operation & Maintenance</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg text-slate-600 mb-4">
                Our comprehensive operation and maintenance services ensure your infrastructure assets perform optimally throughout their lifecycle.
              </p>
              <p className="text-lg text-slate-600 mb-6">
                We provide 24/7 monitoring, preventive maintenance, emergency response, and continuous optimization to maximize uptime and efficiency.
              </p>
              <div className="space-y-3 mb-6">
                {[
                  "Preventive maintenance programs",
                  "24/7 emergency response",
                  "Equipment monitoring and diagnostics",
                  "Performance optimization",
                  "Staff training and support",
                  "Documentation and reporting",
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center">
                    <span className="text-blue-600 mr-3 font-bold">✓</span>
                    <span className="text-slate-600">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/manufactured-sand-plant-8gcqv9YyvXyjmfL3vTcnmo.webp"
                alt="Operation and Maintenance"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Service Approach */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Our Service Approach</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Assessment", desc: "Comprehensive evaluation of your requirements and challenges" },
              { step: "2", title: "Planning", desc: "Detailed strategy and roadmap tailored to your goals" },
              { step: "3", title: "Execution", desc: "Professional implementation with quality assurance" },
              { step: "4", title: "Support", desc: "Ongoing maintenance and continuous improvement" },
            ].map((phase, idx) => (
              <Card key={idx} className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                  {phase.step}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{phase.title}</h3>
                <p className="text-slate-600">{phase.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-blue-600 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Let's discuss how our services can help you achieve your infrastructure goals.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
              Contact Us <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
