import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, CheckCircle, Users, Target, Lightbulb } from "lucide-react";
import { Link } from "wouter";

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 bg-gradient-to-br from-slate-900 to-blue-900 text-white px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">About DevinfraX</h1>
          <p className="text-xl text-blue-100 max-w-2xl">
            Leading the infrastructure revolution with innovation, expertise, and commitment to excellence.
          </p>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-6">Who We Are</h2>
              <p className="text-lg text-slate-600 mb-4">
                DevinfraX is a global infrastructure and industrial solutions provider with a proven track record of delivering complex projects across multiple continents.
              </p>
              <p className="text-lg text-slate-600 mb-4">
                Our team combines engineering excellence, operational efficiency, and innovative thinking to solve the world's most challenging infrastructure problems.
              </p>
              <p className="text-lg text-slate-600">
                Founded on principles of integrity, sustainability, and customer success, we've built lasting partnerships with industry leaders and government agencies worldwide.
              </p>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp"
                alt="DevinfraX Team"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Our Mission & Vision</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-l-4 border-l-blue-600">
              <Target className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Mission</h3>
              <p className="text-lg text-slate-600">
                To deliver world-class infrastructure and industrial solutions that drive sustainable growth, create lasting value, and transform communities through engineering excellence and innovation.
              </p>
            </Card>
            <Card className="p-8 border-l-4 border-l-blue-600">
              <Lightbulb className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Vision</h3>
              <p className="text-lg text-slate-600">
                To be the most trusted and innovative infrastructure partner globally, recognized for delivering exceptional results, fostering sustainable practices, and advancing the future of industrial development.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Company History Timeline */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Our Journey</h2>
          <div className="space-y-8">
            {[
              { year: "1998", title: "Foundation", desc: "DevinfraX founded with a vision to revolutionize infrastructure solutions" },
              { year: "2005", title: "Global Expansion", desc: "Expanded operations to 15 countries across Asia, Europe, and Australia" },
              { year: "2012", title: "Innovation Hub", desc: "Established R&D center for advanced infrastructure technologies" },
              { year: "2018", title: "Sustainability Focus", desc: "Launched comprehensive sustainability and green infrastructure initiatives" },
              { year: "2023", title: "Market Leadership", desc: "Recognized as industry leader with 500+ completed projects globally" },
            ].map((milestone, idx) => (
              <div key={idx} className="flex gap-6 md:gap-12">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                    {idx + 1}
                  </div>
                  {idx < 4 && <div className="w-1 h-20 bg-blue-200 mt-2" />}
                </div>
                <div className="pb-8">
                  <p className="text-blue-600 font-bold text-lg">{milestone.year}</p>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">{milestone.title}</h3>
                  <p className="text-slate-600 text-lg">{milestone.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Why Choose DevinfraX</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Engineering Excellence",
                desc: "Our team of world-class engineers brings decades of combined expertise and proven methodologies to every project.",
              },
              {
                title: "Innovation & Technology",
                desc: "We invest heavily in R&D to bring cutting-edge solutions and sustainable technologies to infrastructure challenges.",
              },
              {
                title: "Global Reach",
                desc: "With operations in 45+ countries, we have the local expertise and global resources to deliver anywhere.",
              },
              {
                title: "Proven Track Record",
                desc: "500+ successfully completed projects demonstrate our ability to deliver on time, on budget, and to specification.",
              },
              {
                title: "Sustainability Focus",
                desc: "Environmental responsibility is core to our operations, ensuring projects create lasting positive impact.",
              },
              {
                title: "Client Partnership",
                desc: "We work as true partners with our clients, aligning our success with theirs and building long-term relationships.",
              },
            ].map((reason, idx) => (
              <Card key={idx} className="p-6 hover:shadow-lg transition-shadow">
                <CheckCircle className="h-8 w-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-bold text-slate-900 mb-3">{reason.title}</h3>
                <p className="text-slate-600">{reason.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Leadership Team</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { name: "Rajesh Kumar", role: "Chief Executive Officer" },
              { name: "Priya Sharma", role: "Chief Technology Officer" },
              { name: "Michael Chen", role: "Chief Operations Officer" },
              { name: "Sarah Johnson", role: "Chief Financial Officer" },
            ].map((leader, idx) => (
              <Card key={idx} className="p-6 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mx-auto mb-4" />
                <h3 className="text-lg font-bold text-slate-900 mb-1">{leader.name}</h3>
                <p className="text-slate-600">{leader.role}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-blue-600 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Join Our Team or Partner With Us</h2>
          <p className="text-xl text-blue-100 mb-8">
            Discover opportunities to grow with DevinfraX or collaborate on your next infrastructure project.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
                Contact Us <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/services">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                Explore Services
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
