import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    subject: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Thank you for your message. We will get back to you soon!");
    setFormData({ name: "", email: "", phone: "", company: "", subject: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 bg-gradient-to-br from-slate-900 to-blue-900 text-white px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Contact Us</h1>
          <p className="text-xl text-blue-100 max-w-2xl">
            Get in touch with our team to discuss your infrastructure and industrial needs.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {[
              {
                icon: Phone,
                title: "Phone",
                content: ["+91 7773970164"],
              },
              {
                icon: Mail,
                title: "Email",
                content: ["devinfrax@gmail.com"],
              },
              {
                icon: MapPin,
                title: "Headquarters",
                content: ["Survey no. 273, Jiregaon", "Tal. Daund, 4138002"],
              },
              {
                icon: Clock,
                title: "Business Hours",
                content: ["Mon - Fri: 9:00 AM - 6:00 PM", "Sat - Sun: Closed"],
              },
            ].map((info, idx) => (
              <Card key={idx} className="p-6 text-center">
                <info.icon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-slate-900 mb-3">{info.title}</h3>
                {info.content.map((line, i) => (
                  <p key={i} className="text-slate-600 text-sm">
                    {line}
                  </p>
                ))}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <input
                    type="text"
                    name="company"
                    placeholder="Company Name"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="">Select Subject</option>
                  <option value="general">General Inquiry</option>
                  <option value="project">Project Discussion</option>
                  <option value="partnership">Partnership Opportunity</option>
                  <option value="support">Support Request</option>
                </select>
                <textarea
                  name="message"
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Map Section */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Location</h2>
              <div className="bg-slate-200 rounded-lg overflow-hidden h-96 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 text-lg">Interactive map would be displayed here</p>
                  <p className="text-slate-500 text-sm mt-2">Survey no. 273, Jiregaon, Tal. Daund, 4138002</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Global Offices */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Global Offices</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { region: "India (HQ)", city: "Jiregaon, Daund", phone: "+91 7773970164" },
              { region: "Europe", city: "London, UK", phone: "+44 (20) 7946-0958" },
              { region: "Asia Pacific", city: "Singapore", phone: "+65 6511-1234" },
              { region: "Middle East", city: "Dubai, UAE", phone: "+971 (4) 308-3333" },
            ].map((office, idx) => (
              <Card key={idx} className="p-6 text-center">
                <h3 className="text-lg font-bold text-slate-900 mb-2">{office.region}</h3>
                <p className="text-slate-600 mb-2">{office.city}</p>
                <p className="text-blue-600 font-semibold">{office.phone}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
