import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Industries() {
  const industries = [
    {
      title: "Construction Industry",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp",
      description: "From residential complexes to commercial hubs, we deliver comprehensive construction solutions with precision and excellence.",
      services: ["Project planning", "Material procurement", "Quality assurance", "Timeline management"],
    },
    {
      title: "Mining Industry",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/mining-operation-PCxFJ5VTe3mHChhJp9YYHH.webp",
      description: "Advanced mining solutions with focus on safety, efficiency, and environmental responsibility.",
      services: ["Mine design", "Equipment supply", "Processing optimization", "Environmental compliance"],
    },
    {
      title: "Infrastructure Projects",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp",
      description: "Large-scale infrastructure development including roads, bridges, tunnels, and utility networks.",
      services: ["Engineering design", "Construction management", "Quality control", "Safety protocols"],
    },
    {
      title: "Road & Highway Projects",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/infrastructure-project-VFtxk55qzXFw8L6BYdo3dQ.webp",
      description: "Modern highway construction and road development with smart infrastructure integration.",
      services: ["Highway design", "Asphalt paving", "Drainage systems", "Traffic management"],
    },
    {
      title: "Urban Development",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp",
      description: "Smart city solutions and urban development projects that transform communities.",
      services: ["Master planning", "Infrastructure integration", "Sustainability focus", "Community engagement"],
    },
    {
      title: "Recycling & Waste Management",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/waste-recycling-facility-9LZVn5J9cD8kbUxjSZGd6a.webp",
      description: "Comprehensive waste management and recycling solutions for sustainable operations.",
      services: ["Facility design", "Equipment supply", "Process optimization", "Environmental management"],
    },
    {
      title: "Energy & Power Plants",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/hero-construction-site-6gFcHSwhtLPwonv4hEfXoc.webp",
      description: "Power generation and energy infrastructure solutions including renewable energy projects.",
      services: ["Plant design", "Equipment installation", "Safety systems", "Maintenance support"],
    },
    {
      title: "Manufactured Sand Solutions",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/manufactured-sand-plant-8gcqv9YyvXyjmfL3vTcnmo.webp",
      description: "Advanced sand washing and processing technology for construction aggregate production.",
      services: ["Plant design", "Equipment supply", "Quality control", "Environmental compliance"],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 bg-gradient-to-br from-slate-900 to-blue-900 text-white px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Industries We Serve</h1>
          <p className="text-xl text-blue-100 max-w-2xl">
            Delivering specialized solutions across diverse sectors with proven expertise and innovation.
          </p>
        </div>
      </section>

      {/* Industries Grid */}
      <section className="py-16 md:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {industries.map((industry, idx) => (
              <Card key={idx} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={industry.image}
                    alt={industry.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-slate-900 mb-3">{industry.title}</h3>
                  <p className="text-slate-600 mb-4">{industry.description}</p>
                  <div className="mb-6">
                    <p className="text-sm font-semibold text-blue-600 mb-2">Our Services:</p>
                    <div className="flex flex-wrap gap-2">
                      {industry.services.map((service, i) => (
                        <span key={i} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
                          {service}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industry Expertise */}
      <section className="py-16 md:py-24 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">Why Industries Trust DevinfraX</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Sector Expertise",
                desc: "Deep understanding of industry-specific requirements, regulations, and best practices.",
              },
              {
                title: "Proven Track Record",
                desc: "Hundreds of successful projects across diverse sectors demonstrate our capability.",
              },
              {
                title: "Innovation",
                desc: "Continuous investment in technology and processes to deliver cutting-edge solutions.",
              },
              {
                title: "Compliance",
                desc: "Full adherence to industry standards, environmental regulations, and safety protocols.",
              },
              {
                title: "Partnership Approach",
                desc: "We work as true partners, aligning our success with your business objectives.",
              },
              {
                title: "Global Resources",
                desc: "Access to worldwide expertise, equipment, and supply chains for any project scale.",
              },
            ].map((reason, idx) => (
              <Card key={idx} className="p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-3">{reason.title}</h3>
                <p className="text-slate-600">{reason.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-blue-600 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Let's Discuss Your Industry Needs</h2>
          <p className="text-xl text-blue-100 mb-8">
            Our team is ready to understand your specific requirements and deliver tailored solutions.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
              Contact Us <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
