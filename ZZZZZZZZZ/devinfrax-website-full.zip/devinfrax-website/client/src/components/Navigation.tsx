import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Services", href: "/services" },
    { label: "Industries", href: "/industries" },
    { label: "Projects", href: "/projects" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 shadow-md z-50" style={{backgroundColor: '#000000'}}>
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663077567977/jeXAXUnHrgx2AKfRCpMDjA/devinfrax-logo-new_f5dc9858.jpg"
              alt="DevinfraX"
              className="h-16 w-auto object-contain"
            />
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
                <span className="hover:text-blue-400 transition-colors cursor-pointer font-medium" style={{color: '#e5e5e5'}}>
                {link.label}
              </span>
            </Link>
          ))}
          <Link href="/contact">
            <Button className="bg-blue-600 hover:bg-blue-700">Contact</Button>
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 rounded-lg"
          style={{color: '#e5e5e5'}}
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden border-t" style={{backgroundColor: '#1a1a1a', borderColor: '#333'}}>
          <div className="max-w-6xl mx-auto px-4 py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className="block hover:text-blue-400 transition-colors cursor-pointer font-medium py-2"
                  style={{color: '#e5e5e5'}}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <Link href="/contact">
              <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => setIsOpen(false)}>
                Contact
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
