# DevinfraX Design System

## Design Philosophy: Modern Industrial Engineering

The DevinfraX website embodies **Professional Minimalism with Engineering Precision**—a design approach that combines clean, modern aesthetics with the authority and credibility required for a global infrastructure company.

### Core Design Principles

1. **Structural Clarity**: Every element serves a purpose. Information architecture is hierarchical and logical, mirroring engineering blueprints.
2. **Trustworthy Simplicity**: Avoid decorative excess. Use white space strategically to create breathing room and focus user attention.
3. **Technical Sophistication**: Incorporate subtle geometric patterns, precise typography, and measured color transitions that evoke engineering precision.
4. **Professional Authority**: Dark blue and grey convey stability, expertise, and corporate reliability.

### Color Palette

- **Primary Blue**: `#1e3a8a` (Dark blue) - Trust, professionalism, engineering
- **Secondary Blue**: `#3b82f6` (Bright blue) - Accent, energy, innovation
- **Neutral Grey**: `#4b5563` (Slate grey) - Secondary text, borders
- **Light Grey**: `#f3f4f6` (Off-white) - Backgrounds, cards
- **White**: `#ffffff` - Primary background, contrast
- **Accent Gold**: `#d97706` (Amber) - Highlights, CTAs (sparingly)

### Typography System

- **Display Font**: `Poppins` (Bold, 700) - Headlines, hero sections (engineering-forward, modern)
- **Body Font**: `Inter` (Regular 400, Medium 500) - Body text, descriptions (clean, readable)
- **Accent Font**: `IBM Plex Mono` (500) - Technical specs, statistics (monospace, engineering feel)

### Layout Paradigm

- **Asymmetric Hero**: Full-width hero with diagonal/angled elements (not centered)
- **Card-Based Sections**: Services, industries, and projects use card layouts with subtle shadows
- **Two-Column Content**: Alternating text/image layouts for visual variety
- **Grid System**: 12-column responsive grid for consistency

### Signature Elements

1. **Diagonal Dividers**: SVG wave/diagonal cuts between sections (engineering aesthetic)
2. **Geometric Accents**: Subtle corner brackets, lines, and shapes in primary blue
3. **Industrial Imagery**: High-quality construction, mining, and infrastructure photos
4. **Icon System**: Consistent, minimal line-based icons (Lucide React)

### Interaction Philosophy

- **Smooth Transitions**: All interactions use 300-400ms easing for professional feel
- **Hover States**: Subtle color shifts and slight scale changes (not aggressive)
- **Button Hierarchy**: Primary (blue), Secondary (outline), Tertiary (text)
- **Loading States**: Animated spinners with professional styling

### Animation Guidelines

- **Entrance Animations**: Fade-in + subtle slide-up (200-300ms) on page load
- **Scroll Animations**: Fade-in on scroll for cards and sections
- **Hover Effects**: Scale 1.02, shadow increase, color shift
- **Transitions**: All UI transitions use `ease-in-out` for smoothness

### Typography Hierarchy

| Element | Font | Size | Weight | Color |
|---------|------|------|--------|-------|
| Hero Title | Poppins | 3.5rem (56px) | 700 | #1e3a8a |
| Section Title | Poppins | 2.5rem (40px) | 700 | #1e3a8a |
| Card Title | Poppins | 1.5rem (24px) | 600 | #1e3a8a |
| Body Text | Inter | 1rem (16px) | 400 | #4b5563 |
| Small Text | Inter | 0.875rem (14px) | 400 | #6b7280 |
| Stat Number | IBM Plex Mono | 2rem (32px) | 500 | #1e3a8a |

### Responsive Design

- **Mobile**: Single column, touch-friendly (48px min tap targets)
- **Tablet**: 2-column layouts, optimized spacing
- **Desktop**: Full 3-4 column layouts, maximum content width 1280px

### Visual Hierarchy

1. **Primary**: Dark blue text on white/light grey backgrounds
2. **Secondary**: Grey text for descriptions and supporting info
3. **Tertiary**: Light grey for borders and subtle elements
4. **Accent**: Bright blue for CTAs and important highlights
